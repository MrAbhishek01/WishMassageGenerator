package com.javatechie.service;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.javatechie.config.CustomUserDetails;
import com.javatechie.customexception.AccessDeniedException;
import com.javatechie.customexception.InvalidCredentialsException;
import com.javatechie.customexception.UserAlreadyExistsException;
import com.javatechie.customexception.UserNotFoundException;
import com.javatechie.dto.AuthRequest;
import com.javatechie.dto.UpdateProfileRequest;
import com.javatechie.entity.UserCredential;
import com.javatechie.repository.UserCredentialRepository;

@Service
public class AuthService {

	@Autowired
	private UserCredentialRepository repository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private JwtService jwtService;

	@Autowired
	private AuthenticationManager authenticationManager;

	public String saveUser(UserCredential credential) {
		Optional<UserCredential> byEmail = repository.findByMobileNumberOrEmail(credential.getMobileNumber(),
				credential.getEmail());
		if (byEmail.isPresent()) {
			throw new UserAlreadyExistsException("This email or mobile number is already registered. Try logging in.");
		}

		credential.setPassword(passwordEncoder.encode(credential.getPassword()));
		credential.setCreatedDate(LocalDateTime.now());
		credential.setUpdatedDate(LocalDateTime.now());
		UserCredential save = repository.save(credential);
		return "User successfully registered with username: " + save.getId();
	}

	public void validateToken(String token) {
		jwtService.validateToken(token);
	}

	public String generateAdminToken(AuthRequest authRequest) {
		try {
			Authentication authentication = authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword()));
			CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
			if ("ADMIN".equals(userDetails.getRole())) {
				return jwtService.generateToken(authRequest.getUsername(), userDetails.getRole());
			} else {
				throw new AccessDeniedException("Only ADMINs are allowed to generate this token.");
			}
		} catch (AuthenticationException e) {
			throw new InvalidCredentialsException("Invalid credentials. Please check your username and password.");
		}
	}

	public String generateCustomerToken(AuthRequest authRequest) {
		try {
			Authentication authentication = authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword()));
			CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
			if ("CUSTOMER".equals(userDetails.getRole())) {
				return jwtService.generateToken(authRequest.getUsername(), userDetails.getRole());
			} else {
				throw new AccessDeniedException("Only CUSTOMERS are allowed to generate this token.");
			}
		} catch (AuthenticationException e) {
			throw new InvalidCredentialsException("Invalid credentials. Please check your username and password.");
		}
	}

	public String generatePasswordResetToken(String email) {
		if (!repository.findByEmail(email).isPresent()) {
			throw new UserNotFoundException("User not found");
		}
		return jwtService.generatePasswordResetToken(email);
	}

	public String resetPassword(String token, String newPassword) {
		String email = jwtService.extractUsername(token);
		UserCredential user = repository.findByEmail(email)
				.orElseThrow(() -> new UserNotFoundException("User not found"));
		user.setPassword(passwordEncoder.encode(newPassword));
		user.setUpdatedDate(LocalDateTime.now());
		UserCredential save = repository.save(user);
		return "Password reset successfully";
	}

	public String updateUserProfile(String email, UpdateProfileRequest updateRequest) {
		UserCredential user = repository.findByEmail(email)
				.orElseThrow(() -> new UserNotFoundException("User not found"));

		// Update fields if provided
		if (updateRequest.getName() != null) {
			user.setName(updateRequest.getName());
		}
		if (updateRequest.getDateOfBirth() != null) {
			user.setDateOfBirth(updateRequest.getDateOfBirth());
		}
		if (updateRequest.getMobileNumber() != null) {
			// Check if mobile number is unique
			Optional<UserCredential> existingUser = repository.findByMobileNumber(updateRequest.getMobileNumber());
			if (existingUser.isPresent() && existingUser.get().getId() != user.getId()) {
				throw new UserAlreadyExistsException("Mobile number already in use");
			}
			user.setMobileNumber(updateRequest.getMobileNumber());
		}

		user.setUpdatedDate(LocalDateTime.now());
		repository.save(user);
		return "Profile updated successfully";
	}

	public String softDeleteUser(String email) {
		UserCredential user = repository.findByEmail(email)
				.orElseThrow(() -> new UserNotFoundException("User not found"));

		user.setDeleted(true);
		user.setUpdatedDate(LocalDateTime.now());
		repository.save(user);
		return "Account deactivated successfully";
	}

}
