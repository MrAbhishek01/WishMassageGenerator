package com.javatechie.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.javatechie.dto.AuthRequest;
import com.javatechie.dto.ResetPasswordRequest;
import com.javatechie.dto.UpdateProfileRequest;
import com.javatechie.entity.UserCredential;
import com.javatechie.service.AuthService;
import com.javatechie.service.JwtService;

@RestController
@RequestMapping("/auth")

public class AuthController {
	@Autowired
	private AuthService service;
	@Autowired
	private JwtService jwtService;

	@PostMapping("/register")
	public ResponseEntity<String> addNewUser(@RequestBody UserCredential user) {
		String saveUser = service.saveUser(user);
		return new ResponseEntity<>(saveUser, HttpStatus.OK);
	}

	@GetMapping("/validate")
	public ResponseEntity<String> validateToken(@RequestParam("token") String token) {
		service.validateToken(token);
		return new ResponseEntity<String>("Token is valid", HttpStatus.OK);
	}

	@PostMapping("/admin/login")
	public ResponseEntity<String> adminLogin(@RequestBody AuthRequest authRequest) {
		String adminToken = service.generateAdminToken(authRequest);
		return new ResponseEntity<>(adminToken, HttpStatus.OK);
	}

	@PostMapping("/customer/login")
	public ResponseEntity<String> customerLogin(@RequestBody AuthRequest authRequest) {
		String customerToken = service.generateCustomerToken(authRequest);
		return new ResponseEntity<>(customerToken, HttpStatus.OK);

	}

	@PostMapping("/forgot-password")
	public ResponseEntity<String> forgotPassword(@RequestParam String email) {
		String resetToken = service.generatePasswordResetToken(email);
		return ResponseEntity.ok("Reset token sent to email: " + resetToken);
	}

	@PostMapping("/reset-password")
	public ResponseEntity<String> resetPassword(@RequestBody ResetPasswordRequest resetRequest) {
		String resetPassword = service.resetPassword(resetRequest.getToken(), resetRequest.getNewPassword());
		return new ResponseEntity<>(resetPassword, HttpStatus.OK);
	}

	@PutMapping("/update-profile")
	public ResponseEntity<String> updateProfile(
	        @RequestBody UpdateProfileRequest updateRequest,
	        @RequestHeader("Authorization") String authHeader) {
	    
	    String token = authHeader.replace("Bearer ", "");
	    String email = jwtService.extractUsername(token);
	    String result = service.updateUserProfile(email, updateRequest);
	    return ResponseEntity.ok(result);
	}

	@DeleteMapping("/delete-account")
	public ResponseEntity<String> deleteAccount(@RequestHeader("Authorization") String authHeader) {

		String token = authHeader.substring(7);
		String email = jwtService.extractUsername(token);
		String result = service.softDeleteUser(email);
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

}
