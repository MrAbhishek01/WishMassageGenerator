package com.javatechie.filter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.cloud.gateway.route.Route;
import org.springframework.cloud.gateway.support.ServerWebExchangeUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.javatechie.util.JwtUtil;

@Component
public class AuthenticationFilter extends AbstractGatewayFilterFactory<AuthenticationFilter.Config> {

    @Autowired
    private RouteValidator validator;

    //    @Autowired
//    private RestTemplate template;
    @Autowired
    private JwtUtil jwtUtil;

    public AuthenticationFilter() {
        super(Config.class);
    }
 // In com.javatechie.filter.AuthenticationFilter
    @Override
    public GatewayFilter apply(Config config) {
        return ((exchange, chain) -> {
            if (validator.isSecured.test(exchange.getRequest())) {
                String authHeader = exchange.getRequest().getHeaders().getFirst(HttpHeaders.AUTHORIZATION);

                if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                    throw new RuntimeException("Missing or invalid authorization header");
                }

                String token = authHeader.substring(7);

                try {
                    jwtUtil.validateToken(token);

                    // Extract role from token
                    String role = jwtUtil.getRoleFromToken(token);
                    if (role == null) {
                        throw new RuntimeException("Role missing in token");
                    }

                    // Get allowed roles from route metadata
                    Route route = exchange.getAttribute(ServerWebExchangeUtils.GATEWAY_ROUTE_ATTR);
                    if (route == null) {
                        throw new RuntimeException("Route configuration error: Route not found");
                    }

                    Map<String, Object> metadata = route.getMetadata();
                    Object rolesObj = metadata.get("allowed-roles");

                    List<String> allowedRoles = new ArrayList<>();
                    if (rolesObj instanceof List) {
                        allowedRoles = (List<String>) rolesObj;
                    } else if (rolesObj instanceof String) {
                        // Handle single role as a comma-separated string
                        String[] rolesArray = ((String) rolesObj).split(",");
                        for (String roleItem : rolesArray) {
                            allowedRoles.add(roleItem.trim());
                        }
                    }

                    // Authorization check
                    if (allowedRoles.isEmpty()) {
                        throw new RuntimeException("Route configuration error: No roles defined");
                    }

                    if (!allowedRoles.contains(role)) {
                        throw new RuntimeException("Insufficient privileges");
                    }

                } catch (Exception e) {
                    throw new RuntimeException("Unauthorized: " + e.getMessage());
                }
            }
            return chain.filter(exchange);
        });
    }

    public static class Config {

    }
}
