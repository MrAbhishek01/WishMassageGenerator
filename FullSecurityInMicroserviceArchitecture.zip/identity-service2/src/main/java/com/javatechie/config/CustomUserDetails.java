package com.javatechie.config;

import java.util.Collection;
import java.util.Collections;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.javatechie.entity.UserCredential;

public class CustomUserDetails implements UserDetails {

    private String username;
    private String password;
    private String role;
    private final String loginIdentifier;
    private boolean active; // Added active status

    public CustomUserDetails(UserCredential userCredential, String loginIdentifier) {
        this.username = userCredential.getUsername();
        this.password = userCredential.getPassword();
        this.role = userCredential.getRole();
        this.loginIdentifier = loginIdentifier;
        this.active = userCredential.isActive(); // Capture active status
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return Collections.singleton(new SimpleGrantedAuthority("ROLE_" + role));
    }

    public String getLoginIdentifier() {
        return loginIdentifier;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getUsername() {
        return username;
    }

    public String getRole() {
        return role;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return active; // Critical: Tie enabled status to active flag
    }
}