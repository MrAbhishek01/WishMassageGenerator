package com.javatechie.service;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.javatechie.config.CustomUserDetails;
import com.javatechie.customexception.AccessDeniedException;
import com.javatechie.customexception.InvalidCredentialsException;
import com.javatechie.customexception.UserAlreadyExistsException;
import com.javatechie.customexception.UserNotFoundException;
import com.javatechie.dto.AuthRequest;
import com.javatechie.dto.UpdateProfileRequest;
import com.javatechie.entity.UserCredential;
import com.javatechie.repository.UserCredentialRepository;

@Service
public class AuthService {

	@Autowired
	private UserCredentialRepository repository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private JwtService jwtService;

	@Autowired
	private AuthenticationManager authenticationManager;

	/**
	 * 
	 * @param credential
	 * @return
	 */
	public String saveUser(UserCredential credential) {
		Optional<UserCredential> existingUser = repository.findByMobileNumberOrEmailOrUsername(
				credential.getMobileNumber(), credential.getEmail(), credential.getUsername());

		if (existingUser.isPresent()) {
			throw new UserAlreadyExistsException("This email or mobile number is already registered");
		}

		credential.setPassword(passwordEncoder.encode(credential.getPassword()));
		credential.setCreatedDate(LocalDateTime.now());
		credential.setUpdatedDate(LocalDateTime.now());
		credential.setActive(true); // Ensure new users are active
		repository.save(credential);
		return "User registered successfully with ID: " + credential.getId();
	}

	public void validateToken(String token) {
		jwtService.validateToken(token);
	}

	public String generateAdminToken(AuthRequest authRequest) {
		try {
			Authentication authentication = authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword()));

			CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();

			// Check account status
			if (!userDetails.isEnabled()) {
				throw new AccessDeniedException("Account deactivated");
			}

			if ("ADMIN".equals(userDetails.getRole())) {
				return jwtService.generateToken(userDetails.getUsername(), userDetails.getRole());
			} else {
				throw new AccessDeniedException("Admin access only");
			}
		} catch (AuthenticationException e) {
			throw new InvalidCredentialsException("Invalid credentials");
		}
	}

	public String generateCustomerToken(AuthRequest authRequest) {
		try {
			Authentication authentication = authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword()));

			CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();

			// Check account status
			if (!userDetails.isEnabled()) {
				throw new AccessDeniedException("Account deactivated");
			}

			if ("CUSTOMER".equals(userDetails.getRole())) {
				return jwtService.generateToken(userDetails.getUsername(), userDetails.getRole());
			} else {
				throw new AccessDeniedException("Customer access only");
			}
		} catch (AuthenticationException e) {
			throw new InvalidCredentialsException("Invalid credentials");
		}
	}

	public String generatePasswordResetToken(String identifier) {
		Optional<UserCredential> user = repository.findByMobileNumberOrEmailOrUsername(identifier, identifier,
				identifier);

		if (!user.isPresent()) {
			throw new UserNotFoundException("User not found");
		}
		// Use ACTUAL username for token
		return jwtService.generatePasswordResetToken(user.get().getUsername());
	}

	/**
	 * 
	 * @param token
	 * @param newPassword changes done username
	 * @return
	 */
	public String resetPassword(String token, String newPassword) {
		String username = jwtService.extractUsername(token);

		UserCredential user = repository.findByUsername(username)
				.orElseThrow(() -> new UserNotFoundException("User not found"));
		user.setPassword(passwordEncoder.encode(newPassword));
		user.setUpdatedDate(LocalDateTime.now());
		UserCredential save = repository.save(user);
		return "Password reset successfully";
	}

	/**
	 * 
	 * @param username
	 * @param updateRequest
	 * @return
	 */
	public String updateUserProfile(String username, UpdateProfileRequest updateRequest) {
		UserCredential user = repository.findByUsername(username)
				.orElseThrow(() -> new UserNotFoundException("User not found"));

		// Update fields if provided
		if (updateRequest.getName() != null) {
			user.setName(updateRequest.getName());
		}
		if (updateRequest.getDateOfBirth() != null) {
			user.setDateOfBirth(updateRequest.getDateOfBirth());
		}
		if (updateRequest.getMobileNumber() != null) {
			// Check if mobile number is unique
			Optional<UserCredential> existingUser = repository.findByMobileNumber(updateRequest.getMobileNumber());
			if (existingUser.isPresent() && existingUser.get().getId() != user.getId()) {
				throw new UserAlreadyExistsException("Mobile number already in use");
			}
			user.setMobileNumber(updateRequest.getMobileNumber());
		}

		user.setUpdatedDate(LocalDateTime.now());
		repository.save(user);
		return "Profile updated successfully";
	}

	/**
	 * 
	 * @param username
	 * @return
	 */
	public String softDeleteUser(String username) {
		UserCredential user = repository.findByMobileNumberOrEmailOrUsername(username, username, username)
				.orElseThrow(() -> new UserNotFoundException("User not found"));

		user.setDeleted(true);
		user.setActive(false); // Deactivate account
		user.setUpdatedDate(LocalDateTime.now());
		repository.save(user);
		return "Account deactivated successfully";
	}

}
