package com.javatechie.entity;

import java.time.LocalDateTime;

import jakarta.persistence.*;

@Entity
public class UserCredential {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private String name;

	@Column(unique = true, nullable = false)
	private String username;

	@Column(unique = true, nullable = false)
	private String email;

	@Column(nullable = false)
	private String password;

	private String role;

	private LocalDateTime dateOfBirth;

	@Column(unique = true, nullable = false)
	private String mobileNumber;

	@Column(nullable = false)
	private boolean isActive;

	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;

	@Column(nullable = false)
	private boolean deleted = false;

	public UserCredential() {
		super();
	}

	@PrePersist
	private void prePersist() {
		// Generate a username if not already provided
		if (this.username == null || this.username.isBlank()) {
			this.username = generateUsername();
		}
		// Set createdDate if null
		if (this.createdDate == null) {
			this.createdDate = LocalDateTime.now();
		}
		// Set isActive default to true
		this.isActive = true;
	}

	private String generateUsername() {
		// Generate username based on name and a random number
		String baseName = name != null ? name.toLowerCase().replaceAll("\\s+", "") : "user";
		int randomNumber = (int) (Math.random() * 10000); // Generate random number up to 9999
		return baseName + randomNumber;
	}

	// Getters and Setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public LocalDateTime getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDateTime dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean active) {
		isActive = active;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	@Override
	public String toString() {
		return "UserCredential [id=" + id + ", name=" + name + ", username=" + username + ", email=" + email
				+ ", password=" + password + ", role=" + role + ", dateOfBirth=" + dateOfBirth + ", mobileNumber="
				+ mobileNumber + ", isActive=" + isActive + ", createdDate=" + createdDate + ", updatedDate="
				+ updatedDate + ", deleted=" + deleted + "]";
	}
}
