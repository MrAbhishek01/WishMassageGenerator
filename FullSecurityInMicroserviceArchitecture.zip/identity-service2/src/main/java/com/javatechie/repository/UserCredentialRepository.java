package com.javatechie.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.javatechie.entity.UserCredential;

@Repository
public interface UserCredentialRepository extends JpaRepository<UserCredential, Integer> {

	Optional<UserCredential> findByUsername(String username);

	Optional<UserCredential> findByMobileNumber(String mobileNumber);

	Optional<UserCredential> findByMobileNumberOrEmailOrUsername(String mobileNumber, String email, String username);
}
