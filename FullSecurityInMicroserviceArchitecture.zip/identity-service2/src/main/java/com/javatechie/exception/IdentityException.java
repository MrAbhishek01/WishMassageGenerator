package com.javatechie.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.javatechie.customexception.AccessDeniedException;
import com.javatechie.customexception.InvalidCredentialsException;
import com.javatechie.customexception.UserAlreadyExistsException;
import com.javatechie.customexception.UserNotFoundException;

@ControllerAdvice
public class IdentityException {

	private ResponseEntity<ErrorResponse> buildResponse(String message, HttpStatus status) {
		ErrorResponse errorResponse = new ErrorResponse(status.value(), status.getReasonPhrase(), message);
		return new ResponseEntity<>(errorResponse, status);
	}

	@ExceptionHandler(UserAlreadyExistsException.class)
	public ResponseEntity<ErrorResponse> handleUserAlreadyExists(UserAlreadyExistsException ex) {
		return buildResponse(ex.getMessage(), HttpStatus.CONFLICT);
	}

	@ExceptionHandler(InvalidCredentialsException.class)
	public ResponseEntity<ErrorResponse> handleInvalidCredentials(InvalidCredentialsException ex) {
		return buildResponse(ex.getMessage(), HttpStatus.UNAUTHORIZED);
	}

	@ExceptionHandler(AccessDeniedException.class)
	public ResponseEntity<ErrorResponse> handleAccessDenied(AccessDeniedException ex) {
		return buildResponse(ex.getMessage(), HttpStatus.FORBIDDEN);
	}

	// Add this handler
	@ExceptionHandler(UserNotFoundException.class)
	public ResponseEntity<ErrorResponse> handleUserNotFound(UserNotFoundException ex) {
		return buildResponse(ex.getMessage(), HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorResponse> handleGenericException(Exception ex) {
		return buildResponse("An unexpected error occurred. Please try again later.", HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
