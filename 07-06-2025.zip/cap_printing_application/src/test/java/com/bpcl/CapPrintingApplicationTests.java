package com.bpcl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapPrintingApplicationTests {

	@Test
	void contextLoads() {
	}

}
