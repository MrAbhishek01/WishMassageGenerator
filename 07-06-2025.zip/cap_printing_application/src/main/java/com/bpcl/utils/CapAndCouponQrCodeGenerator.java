package com.bpcl.utils;

import java.security.SecureRandom;
import java.util.Set;

import org.springframework.stereotype.Component;
@Component
public class CapAndCouponQrCodeGenerator {
	
	 public String generateUniqueAlphanumericCode(String prefix, Integer indentID, String batchUuid, Integer sequence,
             Set<String> generatedCodes) {
     SecureRandom random = new SecureRandom();
     String code;
     do {
             // Generate a random 4-character alphanumeric suffix
             String randomSuffix = random.ints(4, 0, 36)
                             .mapToObj(i -> i < 10 ? String.valueOf(i) : String.valueOf((char) ('A' + i - 10)))
                             .reduce("", (acc, c) -> acc + c);

             // Format: Prefix + Batch (4 chars) + Random Suffix (4 chars)
             String batchPart = batchUuid.substring(0, 4); // First 4 chars of the batch UUID
             code = String.format("%s%s%s", prefix, batchPart, randomSuffix);
     } while (!generatedCodes.add(code)); // Ensure the code is unique
     return code;
}

}
