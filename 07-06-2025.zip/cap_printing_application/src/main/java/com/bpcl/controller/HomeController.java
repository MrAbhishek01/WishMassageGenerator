package com.bpcl.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

	@GetMapping("/")
	public String root() {
		return "redirect:/login";
	}

	@GetMapping("/login")
	public String login() {
		return "login"; // login.html
	}

	@GetMapping("/indent")
	public String indent() {
		return "indent"; // indent.html
	}

	@GetMapping("/dashboard")
	public String dashboard() {
		return "dashboard"; // dashboard.html
	}
}
