package com.bpcl.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.bpcl.model.Indent;

@Repository
public interface IndentRepository extends JpaRepository<Indent, Integer> {

}
