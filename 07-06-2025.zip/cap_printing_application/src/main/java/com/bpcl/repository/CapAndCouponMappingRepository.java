package com.bpcl.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bpcl.model.CapAndCouponMapping;

public interface CapAndCouponMappingRepository extends JpaRepository<CapAndCouponMapping, Integer> {

}
