package com.bpcl.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.bpcl.model.CapQrCode;

@Repository
public interface CapQrCodeRepository extends JpaRepository<CapQrCode, Integer> {

	@Modifying
	@Transactional
	@Query("UPDATE CapQrCode c SET c.status = :newStatus WHERE c.indentID = :indentID AND c.status = :currentStatus")
	String updateStatusByIndentIDAndCurrentStatus(Integer indentID, Integer currentStatus, Integer newStatus);
}
