package com.bpcl.service;

import java.time.LocalDateTime; 
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bpcl.constant.AppConstants;
import com.bpcl.model.Indent;
import com.bpcl.repository.IndentRepository;

@Service
public class IndentService {

	@Autowired
	private IndentRepository indentRepository;

	// Save Indent
	public Indent saveIndent(Indent indent) {
		Optional.ofNullable(indent).orElseThrow(() -> new IllegalArgumentException("Please provide a valid indent"));

		indent.setStatus(AppConstants.ACTIVE_INDENT);
		indent.setLocalDateTime(LocalDateTime.now());

		return indentRepository.save(indent);

	}

	// Cancel Indent
	public String cancelIndent(Integer indentId) {
		Indent indent = indentRepository.findById(indentId)
				.orElseThrow(() -> new IllegalArgumentException("Indent not found for ID: " + indentId));

		indent.setStatus(AppConstants.CANCELED_INDENT); // Update status to canceled
		indent.setLocalDateTime(LocalDateTime.now());
		indentRepository.save(indent);

		return "Indent canceled successfully!";
	}

	// Delete Indent
	public String inactiveIndent(Integer indentId) {
		Indent indent = indentRepository.findById(indentId)
				.orElseThrow(() -> new IllegalArgumentException("Indent not found for ID: " + indentId));

		indent.setStatus(AppConstants.INACTIVE_INDENT); // Update status to canceled
		indent.setLocalDateTime(LocalDateTime.now());
		indentRepository.save(indent);
		return "Indent deleted successfully!";
	}
}
