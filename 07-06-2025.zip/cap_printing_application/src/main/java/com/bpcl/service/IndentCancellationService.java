package com.bpcl.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class IndentCancellationService {
	@Autowired
	private IndentService indentService;

	// private

	public String indentCancellation(Integer indentId) {

		String cancelIndent = indentService.cancelIndent(indentId);

		return null;

	}

}
