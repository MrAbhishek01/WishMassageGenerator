package com.bpcl.dto;

public class CheckListBean {

    private Integer application;
    private Integer kafka;
    private Integer printer;
    private Integer network;
    private Integer internet;  // Add internet check status

    public Integer getApplication() {
        return application;
    }

    public void setApplication(Integer application) {
        this.application = application;
    }

    public Integer getKafka() {
        return kafka;
    }

    public void setKafka(Integer kafka) {
        this.kafka = kafka;
    }

    public Integer getPrinter() {
        return printer;
    }

    public void setPrinter(Integer printer) {
        this.printer = printer;
    }

    public Integer getNetwork() {
        return network;
    }

    public void setNetwork(Integer network) {
        this.network = network;
    }

    public Integer getInternet() {
        return internet;
    }

    public void setInternet(Integer internet) {
        this.internet = internet;
    }
}
