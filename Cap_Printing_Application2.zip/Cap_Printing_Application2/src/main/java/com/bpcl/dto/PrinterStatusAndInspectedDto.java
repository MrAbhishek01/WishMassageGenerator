package com.bpcl.dto;

public class PrinterStatusAndInspectedDto {
	private Integer lotQuantity;
	private Long capQRCount;
	private Long couponQRCount;
	private Long inspectedCount;

	public PrinterStatusAndInspectedDto(Integer lotQuantity, Long capQRCount, Long couponQRCount, Long inspectedCount) {
		super();
		this.lotQuantity = lotQuantity;
		this.capQRCount = capQRCount;
		this.couponQRCount = couponQRCount;
		this.inspectedCount = inspectedCount;
	}

	public Integer getLotQuantity() {
		return lotQuantity;
	}

	public void setLotQuantity(Integer lotQuantity) {
		this.lotQuantity = lotQuantity;
	}

	public Long getCapQRCount() {
		return capQRCount;
	}

	public void setCapQRCount(Long capQRCount) {
		this.capQRCount = capQRCount;
	}

	public Long getCouponQRCount() {
		return couponQRCount;
	}

	public void setCouponQRCount(Long couponQRCount) {
		this.couponQRCount = couponQRCount;
	}

	public Long getInspectedCount() {
		return inspectedCount;
	}

	public void setInspectedCount(Long inspectedCount) {
		this.inspectedCount = inspectedCount;
	}

	@Override
	public String toString() {
		return "PrinterStatusAndInspectedDto [lotQuantity=" + lotQuantity + ", capQRCount=" + capQRCount
				+ ", couponQRCount=" + couponQRCount + ", inspectedCount=" + inspectedCount + "]";
	}

}
