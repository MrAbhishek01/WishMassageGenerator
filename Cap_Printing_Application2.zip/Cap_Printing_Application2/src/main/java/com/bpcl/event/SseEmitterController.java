package com.bpcl.event;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import com.bpcl.dto.PrinterStatusAndInspectedDto;
import com.bpcl.model.CapAndCouponIndent;
import com.bpcl.service.CapAndCouponInspectionService;
import com.bpcl.service.CapQRCodeService;
import com.bpcl.service.CouponQRCodeService;
import com.bpcl.service.PrinterStateService;

@RestController
@RequestMapping("/sse/printer/event")
public class SseEmitterController {

	private final ExecutorService nonBlockingService = Executors.newCachedThreadPool();
	@Autowired
	private CapAndCouponInspectionService capAndCouponInspectionService;

	@Autowired
	private PrinterStateService printerStateService;

	@Autowired
	private CapQRCodeService capQRCodeService;
	@Autowired
	private CouponQRCodeService couponQRCodeService;

	@GetMapping("/sse")
	public SseEmitter handleSse() {
		SseEmitter emitter = new SseEmitter(0L); // No timeout
		 CapAndCouponIndent indent = capAndCouponInspectionService.currentIndent();
		 Long indentID=indent.getId();
		nonBlockingService.execute(() -> {
			try {
              
				// Get quantities from services
				Integer lotQty = printerStateService.getLotQuantity();
				Long capCount = capQRCodeService.getPrintedCapCount(indentID);
				Long couponCount = couponQRCodeService.getPrintedCouponCount(indentID);
				Long inspectedCount = 0l;
				PrinterStatusAndInspectedDto dto = new PrinterStatusAndInspectedDto(lotQty, capCount, couponCount,
						inspectedCount);

				System.err.println(dto);
				System.out.println("Sending SSE data - LotQty: " + lotQty + ", CapCount: " + capCount
						+ ", CouponCount: " + couponCount + ",InspectedCount: " + inspectedCount);

				// Send data via SSE
				emitter.send(SseEmitter.event().name("printer-data").data(dto));

				emitter.complete();
			} catch (Exception ex) {
				System.err.println("Error in SSE execution: " + ex.getMessage());
				emitter.completeWithError(ex);
			}
		});

		// Error handling
		emitter.onError(ex -> {
			System.err.println("SSE error: " + ex.getMessage());
		});

		// Completion handling
		emitter.onCompletion(() -> {
			System.out.println("SSE connection completed");
		});

		return emitter;
	}
}