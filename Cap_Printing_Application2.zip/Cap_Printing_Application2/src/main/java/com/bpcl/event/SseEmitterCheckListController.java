package com.bpcl.event;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import com.bpcl.dto.CheckListBean;
import com.bpcl.utils.IpPing;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping("/sse/check/list/event")
public class SseEmitterCheckListController {

    @Value("${kafka.ip}")
    private String kafkaIp;

    @Value("${kafka.port}")
    private int kafkaPort;

    @Value("${printer.ip}")
    private String printerIp;

    @Value("${printer.port}")
    private int printerPort;

    private final ExecutorService nonBlockingService = Executors.newCachedThreadPool();

    @Autowired
    private ObjectMapper objectMapper;

    @GetMapping("/sseCheckList")
    public SseEmitter handleSseEvent() {
        System.out.println("SSE Event endpoint hit - starting status checks...");
        SseEmitter emitter = new SseEmitter(TimeUnit.MINUTES.toMillis(5)); // 5-minute timeout
        AtomicBoolean isActive = new AtomicBoolean(true);
        
        // Set completion handlers
        emitter.onCompletion(() -> {
            System.out.println("SSE connection completed");
            isActive.set(false);
        });
        
        emitter.onTimeout(() -> {
            System.out.println("SSE connection timed out");
            isActive.set(false);
        });
        
        // Start status checks
        nonBlockingService.execute(() -> {
            try {
                while (isActive.get()) {
                    CheckListBean checklist = performStatusChecks();
                    String jsonData = objectMapper.writeValueAsString(checklist);
                    
                    try {
                        emitter.send(SseEmitter.event()
                                .data(jsonData)
                                .name("status-update"));
                        System.out.println("Sent status update: " + jsonData);
                    } catch (IOException ex) {
                        System.err.println("SSE send error: " + ex.getMessage());
                        emitter.completeWithError(ex);
                        isActive.set(false);
                    }
                    
                    // Wait before next check
                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException ex) {
                        Thread.currentThread().interrupt();
                        isActive.set(false);
                    }
                }
            } catch (Exception ex) {
                System.err.println("SSE processing error: " + ex.getMessage());
                emitter.completeWithError(ex);
            } finally {
                emitter.complete();
            }
        });
        
        return emitter;
    }

    private CheckListBean performStatusChecks() throws IOException {
        CheckListBean checklist = new CheckListBean();
        
        // Printer check
        boolean printerStatus = IpPing.ipPingWithPort(printerIp, printerPort);
        checklist.setPrinter(printerStatus ? 0 : 1);
        System.out.println("Printer status: " + (printerStatus ? "UP" : "DOWN"));

        // Kafka check
        boolean kafkaStatus = IpPing.ipPingWithPort(kafkaIp, kafkaPort);
        checklist.setKafka(kafkaStatus ? 0 : 1);
        System.out.println("Kafka status: " + (kafkaStatus ? "UP" : "DOWN"));

        // Network check (using Google DNS)
        boolean networkStatus = IpPing.ipPing("8.8.8.8");
        checklist.setNetwork(networkStatus ? 0 : 1);
        System.out.println("Network status: " + (networkStatus ? "UP" : "DOWN"));
        
        return checklist;
    }

    @RequestMapping("/checklist")
    public String checklistPage() {
        return "checklist";
    }
}