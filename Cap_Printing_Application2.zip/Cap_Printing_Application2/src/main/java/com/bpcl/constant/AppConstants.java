package com.bpcl.constant;

/**
 * 
 * @author S.K.R.SUBRAMANYAM REDDY GUIDE BY MR.HIRANAYA SIR
 *
 */
public class AppConstants {

	public static final String TOPIC_NAME = "couponInspection";

	public static final String GROUP_ID = "couponInspection";

	public static final Integer INDENT_NEW_STATUS = 0;
	
	public static final Integer INDENT_OVER_STATUS = 2;
	
	public static final Integer INDENT_CANCLE_STATUS = 5;
	
	public static final Integer COUPON_PRINTED_STATUS_3 = 3;

	public static final Integer COUPON_UPDATE_SATVIK_COUPON_VALID_STATUS_4 = 4;

	public static final Integer COUPON_UPDATE_SENDING_COUPON_TO_KAFKA_STATUS_5 = 5;
	
	public static final Integer COUPONPODUCTION_NEW_STATUS_0 = 0;
	
	public static final Integer COUPONPODUCTION_PRINTING_START_STATUS_1 = 1;
	
	public static final Integer COUPONPODUCTION_PRINTING_OVER_STATUS_2 = 2;
	
}
