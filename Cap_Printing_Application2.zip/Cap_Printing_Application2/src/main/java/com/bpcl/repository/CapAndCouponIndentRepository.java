package com.bpcl.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.bpcl.model.CapAndCouponIndent;
import java.util.List;

@Repository
public interface CapAndCouponIndentRepository extends JpaRepository<CapAndCouponIndent, Long> {

	/*@Query(value = "SELECT * FROM cap_and_coupon_indent " + "ORDER BY create_time DESC LIMIT 1", nativeQuery = true)
	Optional<CapAndCouponIndent> findLatestEntry();*/
	Optional<CapAndCouponIndent>  findByStatusOrStatus(Integer active, Integer inactive);
	@Query(value = "SELECT * FROM cap_and_coupon_indent WHERE status = :status ORDER BY create_time DESC LIMIT 1", nativeQuery = true)
	Optional<CapAndCouponIndent> findLatestEntryByActiveStatus(int status);
}
