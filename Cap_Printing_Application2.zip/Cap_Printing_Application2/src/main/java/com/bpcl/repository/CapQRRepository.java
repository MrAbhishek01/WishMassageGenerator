package com.bpcl.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bpcl.model.CapQRCode;

@Repository
public interface CapQRRepository extends JpaRepository<CapQRCode, String> {
	long countByStatusAndIndentID(Integer status, Long indentID);

	CapQRCode findByCapCodeAndIndentIDAndStatus(String capCode, Long indentID, Integer status);
	
	

	@Query("SELECT c FROM CapQRCode c WHERE c.indentID = :indentID AND c.status = :status")
	List<CapQRCode> findAllByIndentIDAndStatus(@Param("indentID") Long indentID, @Param("status") Integer status);
}
