package com.bpcl.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bpcl.model.CouponQRCode;

@Repository
public interface CouponQRRepository extends JpaRepository<CouponQRCode, String> {
	long countByStatusAndIndentID(Integer status, Long indentID);

	CouponQRCode findByCouponCodeAndIndentIDAndStatus(String couponCode, Long indentID, Integer status);

	// CouponQRCode findByCouponCode(String couponCode);
	@Query("SELECT c FROM CouponQRCode c WHERE c.indentID = :indentID AND c.status = :status")
	List<CouponQRCode> findAllByIndentIDAndStatus(@Param("indentID") Long indentID, @Param("status") Integer status);

}
