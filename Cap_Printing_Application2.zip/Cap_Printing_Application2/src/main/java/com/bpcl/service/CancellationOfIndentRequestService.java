package com.bpcl.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bpcl.constant.AppConstants;
import com.bpcl.model.CapAndCouponIndent;
import com.bpcl.model.CapQRCode;
import com.bpcl.model.CouponQRCode;
import com.bpcl.repository.CapAndCouponIndentRepository;
import com.bpcl.repository.CapQRRepository;
import com.bpcl.repository.CouponQRRepository;
import com.bpcl.utils.CapAndCouponPrinterThread;

@Service
public class CancellationOfIndentRequestService {

    @Autowired
    private CapAndCouponIndentRepository capAndCouponIndentRepository;

    @Autowired
    private CouponQRRepository couponQRRepository;

    @Autowired
    private CapQRRepository capQRRepository;

    @Autowired
    private CapAndCouponInspectionService capAndCouponInspectionService;

   
    
    @Autowired
	  private ThreadManagementService threadManagementService;


    public String cancelIndent() {
		String stopThread = threadManagementService.stopThread();
        // Fetch the current indent
        CapAndCouponIndent indent = capAndCouponInspectionService.currentIndent();
        Long id = indent.getId();

        // Fetch and update CapQRCode statuses
        List<CapQRCode> capQRCodes = capQRRepository.findAllByIndentIDAndStatus(id, AppConstants.INDENT_NEW_STATUS);
        capQRCodes.forEach(capQRCode -> capQRCode.setStatus(AppConstants.INDENT_CANCLE_STATUS));
        capQRRepository.saveAll(capQRCodes);

        // Fetch and update CouponQRCode statuses
        List<CouponQRCode> couponQRCodes = couponQRRepository.findAllByIndentIDAndStatus(id,
                AppConstants.INDENT_NEW_STATUS);
        couponQRCodes.forEach(couponQRCode -> couponQRCode.setStatus(AppConstants.INDENT_CANCLE_STATUS));
        couponQRRepository.saveAll(couponQRCodes);

        // Update the CapAndCouponIndent status
        Optional<CapAndCouponIndent> byId = capAndCouponIndentRepository.findById(id);
        if (byId.isPresent()) {
            CapAndCouponIndent capAndCouponIndent = byId.get();
            capAndCouponIndent.setStatus(AppConstants.INDENT_CANCLE_STATUS);
            capAndCouponIndentRepository.save(capAndCouponIndent);
        }

        return "Indent cancelled successfully";
    }
}
