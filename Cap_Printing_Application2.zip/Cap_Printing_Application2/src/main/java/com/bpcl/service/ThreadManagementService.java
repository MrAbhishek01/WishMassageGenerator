package com.bpcl.service;



import org.springframework.stereotype.Service;

import com.bpcl.utils.CapAndCouponPrinterThread;

@Service
public class ThreadManagementService {

    private Thread currentThread;
    private CapAndCouponPrinterThread printerThread;

    public synchronized String startThread(CapAndCouponPrinterThread task) {
        if (currentThread != null && currentThread.isAlive()) {
            return "A thread is already running.";
        }

        printerThread = task;
        currentThread = new Thread(printerThread);
        currentThread.start();
        return "Thread started successfully.";
    }

    public synchronized String stopThread() {
        if (currentThread != null && currentThread.isAlive()) {
            printerThread.stop(); // Signal the thread to stop
            try {
                currentThread.join(); // Wait for the thread to terminate
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return "Thread stop interrupted.";
            }
            currentThread = null; // Clear the reference
            return "Thread stopped successfully.";
        }
        return "No active thread to stop.";
    }

    public boolean isThreadRunning() {
        return currentThread != null && currentThread.isAlive();
    }
}
