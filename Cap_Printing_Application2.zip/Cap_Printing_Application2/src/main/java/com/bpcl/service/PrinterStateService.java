package com.bpcl.service;

import java.util.NoSuchElementException; 
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bpcl.model.PrinterState;
import com.bpcl.repository.PrinterStateRepository;

@Service
public class PrinterStateService  {

	@Autowired
	private PrinterStateRepository printerStateRepository;


	public void updateState(PrinterState printerState) {
		PrinterState printerStateDetails = this.getPrinterStateDetails();
		{
			if (printerStateDetails != null) {
				printerStateRepository.save(printerState);
			}
		}

	}


	public PrinterState getPrinterStateDetails() {
		Long id = 9000L;

		Optional<PrinterState> existing = printerStateRepository.findById(id);
		if (existing.isPresent()) {
			return existing.get();
		} else {
			throw new RuntimeException("PrinterState with ID " + id + " not found");
		}
	}


	public void defaultSaveDetails() {
		PrinterState printerState = new PrinterState();
		printerState.setUuid(9000l);
		printerState.setLotQty(0);
		printerState.setProgressBarValue(0);
		printerState.setPrint(0);
		printerState.setMessage("printer is stoped");
		printerStateRepository.save(printerState);

	}


	public Integer getLotQuantity() {
		Long id = 9000L;

		Optional<PrinterState> existing = printerStateRepository.findById(id);
		if (existing.isPresent()) {
			PrinterState printerState = existing.get();
			return printerState.getLotQty(); // ✅ Return the value
		} else {
			throw new NoSuchElementException("Indent not present");
		}
	}

}
