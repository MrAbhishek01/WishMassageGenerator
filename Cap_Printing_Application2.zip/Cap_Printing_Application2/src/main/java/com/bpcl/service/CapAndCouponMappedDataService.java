package com.bpcl.service;

import org.springframework.stereotype.Service;

@Service
public class CapAndCouponMappedDataService {

}
