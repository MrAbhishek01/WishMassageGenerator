package com.bpcl.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bpcl.constant.AppConstants;
import com.bpcl.model.CapQRCode;
import com.bpcl.repository.CapQRRepository;

@Service
public class CapQRCodeService {
	@Autowired
	private CapQRRepository capQRRepository;

	public String insertCapQrCode(List<CapQRCode> capQRCodes) {
		capQRRepository.saveAll(capQRCodes);
		return "Cap QR printed successfully";

	}

	public Long getPrintedCapCount(Long indent) {

		long count = capQRRepository.countByStatusAndIndentID(AppConstants.COUPON_PRINTED_STATUS_3, indent);
		return count;

	}

	public List<CapQRCode> getAllCapCodes(Long indent, Integer status) {
		List<CapQRCode> allCapQRCode = capQRRepository.findAllByIndentIDAndStatus(indent, status);
		//List<CapQRCode> allCapQRCode = capQRRepository.findAll();
		return allCapQRCode;
	}

	public void updateCapStatus(String couponCode, Integer status, Long indent) {

		CapQRCode capQRCode = capQRRepository.findByCapCodeAndIndentIDAndStatus(couponCode, indent,
				AppConstants.COUPONPODUCTION_NEW_STATUS_0);
		if (capQRCode != null) {
			capQRCode.setStatus(status);
			capQRRepository.save(capQRCode);
		}

	}
}
