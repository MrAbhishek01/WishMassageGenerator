package com.bpcl.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bpcl.constant.AppConstants;
import com.bpcl.model.CapQRCode;
import com.bpcl.model.CouponQRCode;
import com.bpcl.repository.CouponQRRepository;

@Service
public class CouponQRCodeService {
	@Autowired
	private CouponQRRepository couponQRRepository;

	public String insertCouponQrCode(List<CouponQRCode> couponQRCodes) {
		couponQRRepository.saveAll(couponQRCodes);
		return "Coupon QR printed successfully";

	}

	public Long getPrintedCouponCount(Long indent) {
		long count = couponQRRepository.countByStatusAndIndentID(AppConstants.COUPON_PRINTED_STATUS_3, indent);
		return count;

	}

//new impli

	public List<CouponQRCode> getAllCouponCodes(Long indent, Integer status) {
		List<CouponQRCode> allCouponQRCode = couponQRRepository.findAllByIndentIDAndStatus(indent, status);
		// List<CouponQRCode> allCouponQRCode = couponQRRepository.findAll();
		return allCouponQRCode;
	}

	public void updateCouponStatus(String couponCode, Integer status, Long indent) {
		CouponQRCode couponQRCode = couponQRRepository.findByCouponCodeAndIndentIDAndStatus(couponCode, indent,
				AppConstants.COUPONPODUCTION_NEW_STATUS_0);
		if (couponQRCode != null) {
			couponQRCode.setStatus(status);
			couponQRRepository.save(couponQRCode);
		}
	}
}
