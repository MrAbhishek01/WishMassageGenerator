package com.bpcl.service;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.bpcl.constant.AppConstants;
import com.bpcl.model.CapAndCouponIndent;
import com.bpcl.model.CapQRCode;
import com.bpcl.model.CouponQRCode;
import com.bpcl.model.PrinterState;
import com.bpcl.repository.CapAndCouponIndentRepository;
import com.bpcl.utils.CapAndCouponPrinterThread;

@Service
public class CapAndCouponInspectionService {

	@Autowired
	private ThreadManagementService threadManagementService;
	@Autowired
	private CouponQRCodeService couponQRCodeService;

	@Autowired
	private CapQRCodeService capQRCodeService;

	@Autowired
	private PrinterStateService printerStateService;

	@Autowired
	private CapAndCouponIndentRepository indentRepository;

	@Autowired
	@Lazy
	private CapAndCouponPrinterThread printerThread;

	/*private String convertCapBarcodeString;
	
	private String convertCouponBarcodeString;*/

	public String generateCapAndCouponQRCode(CapAndCouponIndent capAndCouponIndent) {
		// printerStateService.defaultSaveDetails();
		capAndCouponIndent.setCreateTime(LocalDateTime.now());
		capAndCouponIndent.setStatus(AppConstants.INDENT_NEW_STATUS);
		indentRepository.save(capAndCouponIndent);

		PrinterState printerState = printerStateService.getPrinterStateDetails();
		printerState.setLotQty(capAndCouponIndent.getLotQty());
		printerState.setPrint(capAndCouponIndent.getLotQty() - printerState.getProgressBarValue());
		printerStateService.updateState(printerState);

		String batchUuid = UUID.randomUUID().toString();
		Set<String> generatedCodes = new HashSet<>();
		List<CapQRCode> capQRList = new ArrayList<>();
		List<CouponQRCode> couponQRList = new ArrayList<>();

		String indentIdStr = String.valueOf(capAndCouponIndent.getId());
		if (indentIdStr.length() > 8) {
			indentIdStr = indentIdStr.substring(0, 8);
		} else {

			indentIdStr = String.format("%8s", indentIdStr).replace(' ', '0');
		}

		for (int i = 1; i <= capAndCouponIndent.getLotQty(); i++) {
			String seq = String.format("%02d", i);
			String capCode = generateUniqueAlphanumericCode("CP", capAndCouponIndent.getId(), batchUuid, i,
					generatedCodes);
			CapQRCode capQRCode = new CapQRCode();
			capQRCode.setUuid(UUID.randomUUID().toString());
			capQRCode.setCapCode(capCode);
			capQRCode.setIndentID(capAndCouponIndent.getId());
			capQRCode.setCreateTime(LocalDateTime.now());
			capQRCode.setStatus(AppConstants.COUPONPODUCTION_NEW_STATUS_0);

			capQRList.add(capQRCode);

			String couponCode = generateUniqueAlphanumericCode("CO", capAndCouponIndent.getId(), batchUuid, i,
					generatedCodes);

			CouponQRCode couponQRCode = new CouponQRCode();
			couponQRCode.setUuid(UUID.randomUUID().toString());
			couponQRCode.setCouponCode(couponCode);
			couponQRCode.setIndentID(capAndCouponIndent.getId());
			couponQRCode.setCreateTime(LocalDateTime.now());
			couponQRCode.setStatus(AppConstants.COUPONPODUCTION_NEW_STATUS_0);

			couponQRList.add(couponQRCode);
		}
		String insertCapQrCode = capQRCodeService.insertCapQrCode(capQRList);
		String insertCouponQrCode = couponQRCodeService.insertCouponQrCode(couponQRList);
		CapAndCouponPrinterThread capAndCouponPrinterThread = new CapAndCouponPrinterThread(capQRCodeService,
				couponQRCodeService, this, printerStateService);
		threadManagementService.startThread(capAndCouponPrinterThread);
		return "Indent successfully submitted";

	}

	private String generateUniqueAlphanumericCode(String prefix, Long indentID, String batchUuid, int sequence,
			Set<String> generatedCodes) {
		SecureRandom random = new SecureRandom();
		String code;
		do {
			// Generate a random 4-character alphanumeric suffix
			String randomSuffix = random.ints(4, 0, 36)
					.mapToObj(i -> i < 10 ? String.valueOf(i) : String.valueOf((char) ('A' + i - 10)))
					.reduce("", (acc, c) -> acc + c);

			// Format: Prefix + Batch (4 chars) + Random Suffix (4 chars)
			String batchPart = batchUuid.substring(0, 4); // First 4 chars of the batch UUID
			code = String.format("%s%s%s", prefix, batchPart, randomSuffix);
		} while (!generatedCodes.add(code)); // Ensure the code is unique
		return code;
	}

	public Integer getLotQuentity() {
		Optional<CapAndCouponIndent> latestEntry = indentRepository
				.findLatestEntryByActiveStatus(AppConstants.INDENT_NEW_STATUS);
		if (latestEntry.isPresent()) {
			CapAndCouponIndent capAndCouponIndent = latestEntry.get();
			Integer lotQty = capAndCouponIndent.getLotQty();
			return lotQty;
		} else {
			throw new IllegalArgumentException("");
		}

	}

	public CapAndCouponIndent currentIndent() {
		Optional<CapAndCouponIndent> latestEntry = indentRepository
				.findLatestEntryByActiveStatus(AppConstants.INDENT_NEW_STATUS);
		if (latestEntry.isPresent()) {

			CapAndCouponIndent capAndCouponIndent = latestEntry.get();

			return capAndCouponIndent;
		} else {
			throw new IllegalArgumentException("");
		}

	}

	public void updateIndentStatus(int status) {
		// Assume currentIndent() fetches the current indent object
		CapAndCouponIndent currentIndent = currentIndent();
		if (currentIndent != null) {
			currentIndent.setStatus(status);
			indentRepository.save(currentIndent); // Save updated status
			System.out.println("Indent status updated to: " + status);
		} else {
			System.out.println("No current indent found to update.");
		}
	}

}