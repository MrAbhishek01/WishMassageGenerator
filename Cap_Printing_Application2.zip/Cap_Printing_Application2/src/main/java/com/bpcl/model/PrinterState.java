package com.bpcl.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class PrinterState {
	@Id
	private Long uuid=9000l;

	private String message;

	private Integer print;

	private Integer lotQty;

	private Integer progressBarValue;

	public Long getUuid() {
		return uuid;
	}

	public void setUuid(Long uuid) {
		this.uuid = uuid;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Integer getPrint() {
		return print;
	}

	public void setPrint(Integer print) {
		this.print = print;
	}

	public Integer getLotQty() {
		return lotQty;
	}

	public void setLotQty(Integer lotQty) {
		this.lotQty = lotQty;
	}

	public Integer getProgressBarValue() {
		return progressBarValue;
	}

	public void setProgressBarValue(Integer progressBarValue) {
		this.progressBarValue = progressBarValue;
	}

}
