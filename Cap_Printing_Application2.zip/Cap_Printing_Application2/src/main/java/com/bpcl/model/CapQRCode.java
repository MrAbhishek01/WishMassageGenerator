package com.bpcl.model;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class CapQRCode {
	@Id
	private String uuid;

	private String capCode;

	private Long indentID;

	private LocalDateTime createTime;

	private Integer status;

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}


	public String getCapCode() {
		return capCode;
	}

	public void setCapCode(String capCode) {
		this.capCode = capCode;
	}

	public Long getIndentID() {
		return indentID;
	}

	public void setIndentID(Long indentID) {
		this.indentID = indentID;
	}

	public LocalDateTime getCreateTime() {
		return createTime;
	}

	public void setCreateTime(LocalDateTime createTime) {
		this.createTime = createTime;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "CapQRCode [uuid=" + uuid + ", capCode=" + capCode + ", indentID=" + indentID + ", createTime="
				+ createTime + ", status=" + status + "]";
	}

	
}
