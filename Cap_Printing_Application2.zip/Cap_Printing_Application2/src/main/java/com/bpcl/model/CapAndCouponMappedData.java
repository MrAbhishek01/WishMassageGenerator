package com.bpcl.model;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
@Entity
public class CapAndCouponMappedData {
	@Id
	private String uuid;

	private Integer locCode;

	private String couponCode;

	private String capCode;

	private String lotQty;

	private LocalDateTime createTime;

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public Integer getLocCode() {
		return locCode;
	}

	public void setLocCode(Integer locCode) {
		this.locCode = locCode;
	}

	public String getCouponCode() {
		return couponCode;
	}

	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}

	public String getCapCode() {
		return capCode;
	}

	public void setCapCode(String capCode) {
		this.capCode = capCode;
	}

	public String getLotQty() {
		return lotQty;
	}

	public void setLotQty(String lotQty) {
		this.lotQty = lotQty;
	}

	public LocalDateTime getCreateTime() {
		return createTime;
	}

	public void setCreateTime(LocalDateTime createTime) {
		this.createTime = createTime;
	}

	@Override
	public String toString() {
		return "CapAndCouponMappedData [uuid=" + uuid + ", locCode=" + locCode + ", couponCode=" + couponCode
				+ ", capCode=" + capCode + ", lotQty=" + lotQty + ", createTime=" + createTime + "]";
	}

}
