package com.bpcl.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bpcl.model.CapAndCouponIndent;
import com.bpcl.service.CancellationOfIndentRequestService;
import com.bpcl.service.CapAndCouponInspectionService;

@RestController
@RequestMapping("/indentAction")
public class CapAndCouponIndentActionController {
	@Autowired
	private CancellationOfIndentRequestService cancellationOfIndentRequestService;
	@Autowired
	private CapAndCouponInspectionService capAndCouponInspectionService;

	@GetMapping("/cancleIndent")
	public ResponseEntity<String> cancleIndent() {
		String cancleIndent = cancellationOfIndentRequestService.cancelIndent();
		System.err.println("cancellation done");
		return new ResponseEntity<>(cancleIndent, HttpStatus.OK);
	}

	/*@PostMapping("/CapAndCouponIndent")
	public ResponseEntity<String> processIndent(@RequestBody CapAndCouponIndent capAndCouponIndent) {
	
		String result = capAndCouponInspectionService.generateCapAndCouponQRCode(capAndCouponIndent);
	
		return new ResponseEntity<String>(result, HttpStatus.OK);
	}*/

}
