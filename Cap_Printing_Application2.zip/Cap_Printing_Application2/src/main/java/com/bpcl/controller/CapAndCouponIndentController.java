package com.bpcl.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.bpcl.constant.AppConstants;
import com.bpcl.model.CapAndCouponIndent;
import com.bpcl.repository.CapAndCouponIndentRepository;
import com.bpcl.service.CancellationOfIndentRequestService;
import com.bpcl.service.CapAndCouponInspectionService;
import com.bpcl.service.PrinterStateService;

@Controller
public class CapAndCouponIndentController {
	@Autowired
	private CapAndCouponInspectionService capAndCouponInspectionService;
	@Autowired
	private PrinterStateService printerStateService;
	@Autowired
	private CapAndCouponIndentRepository capAndCouponIndentRepository;
	@Autowired
	private CancellationOfIndentRequestService cancellationOfIndentRequestService;

	@GetMapping("/")
	public String homePage(@ModelAttribute CapAndCouponIndent capAndCouponIndent, Model model) {
		// Check for active indent
		Optional<CapAndCouponIndent> activeIndent = capAndCouponIndentRepository
				.findLatestEntryByActiveStatus(AppConstants.INDENT_NEW_STATUS);

		if (activeIndent.isPresent()) {
			model.addAttribute("errorMessage", "An indent is already in progress!");
			return "showIndent";
		}
		return "welcome";
	}


	@PostMapping("/CapAndCouponIndent")
	public String processIndent(@ModelAttribute CapAndCouponIndent capAndCouponIndent,
			RedirectAttributes redirectAttributes) {

		String result = capAndCouponInspectionService.generateCapAndCouponQRCode(capAndCouponIndent);
		redirectAttributes.addFlashAttribute("serviceResult", result);
		/*
				zsOptional<CapAndCouponIndent> indentStatus = capAndCouponIndentRepository
						.findByStatusOrStatus(AppConstants.INDENT_CANCLE_STATUS, AppConstants.INDENT_OVER_STATUS);
		
				if (indentStatus.isPresent()) {
					redirectAttributes.addFlashAttribute("errorMessage", "Indent already processed or cancelled.");
					return "redirect:/";
				}*/

		return "redirect:/showIndent";
	}
	@GetMapping("/showIndent")
	public String showIndent() {
		return "showIndent";
	}

}
