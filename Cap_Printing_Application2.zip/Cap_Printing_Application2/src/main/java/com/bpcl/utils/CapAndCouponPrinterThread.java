package com.bpcl.utils;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import com.bpcl.constant.AppConstants;
import com.bpcl.model.CapAndCouponIndent;
import com.bpcl.model.CapQRCode;
import com.bpcl.model.CouponQRCode;
import com.bpcl.model.PrinterState;
import com.bpcl.service.CapAndCouponInspectionService;
import com.bpcl.service.CapQRCodeService;
import com.bpcl.service.CouponQRCodeService;
import com.bpcl.service.PrinterStateService;

public class CapAndCouponPrinterThread implements Runnable {

	private final CapQRCodeService capQRCodeService;
	private final CouponQRCodeService couponQRCodeService;
	private final CapAndCouponInspectionService capAndCouponInspectionService;
	private final PrinterStateService printerStateService;
	private final AtomicBoolean running = new AtomicBoolean(true);

	public CapAndCouponPrinterThread(CapQRCodeService capQRCodeService, CouponQRCodeService couponQRCodeService,
			CapAndCouponInspectionService capAndCouponInspectionService, PrinterStateService printerStateService) {
		super();
		this.capQRCodeService = capQRCodeService;
		this.couponQRCodeService = couponQRCodeService;
		this.capAndCouponInspectionService = capAndCouponInspectionService;
		this.printerStateService = printerStateService;
	}

	@Override
	public void run() {
		while (running.get()) {
			try {
				startProcessing();
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				break;
			}
		}
		System.out.println("Thread gracefully stopped.");
	}

	public void stop() {
		printerStateService.defaultSaveDetails();
		running.set(false);
	}

	private void startProcessing() throws InterruptedException {
		CapAndCouponIndent indent = capAndCouponInspectionService.currentIndent();
		Long indentId = indent.getId();
		PrinterState printerStateDetails = printerStateService.getPrinterStateDetails();
		List<CapQRCode> capCodes = capQRCodeService.getAllCapCodes(indentId, AppConstants.COUPONPODUCTION_NEW_STATUS_0);
		List<CouponQRCode> couponCodes = couponQRCodeService.getAllCouponCodes(indentId,
				AppConstants.COUPONPODUCTION_NEW_STATUS_0);

		int maxSize = Math.max(capCodes.size(), couponCodes.size());
		for (int i = 0; i < maxSize; i++) {
			if (!running.get()) {
				System.out.println("Thread stopping mid-execution...");
				return;
			}

			// Process CapQRCode
			if (i < capCodes.size()) {
				CapQRCode capCode = capCodes.get(i);
				System.out.println("Processing CapQRCode: " + capCode.getCapCode());
				capQRCodeService.updateCapStatus(capCode.getCapCode(), 3, indentId);
			}

			// Process CouponQRCode
			if (i < couponCodes.size()) {
				CouponQRCode couponCode = couponCodes.get(i);
				System.out.println("Processing CouponQRCode: " + couponCode.getCouponCode());
				couponQRCodeService.updateCouponStatus(couponCode.getCouponCode(), 3, indentId);
			}
			printerStateDetails.setProgressBarValue(i);
			printerStateService.updateState(printerStateDetails);
			Thread.sleep(5000); // Delay between processing each pair
		}

		capAndCouponInspectionService.updateIndentStatus(AppConstants.INDENT_OVER_STATUS);
		printerStateService.defaultSaveDetails();
		System.out.println("Processing completed.");
	}
}
