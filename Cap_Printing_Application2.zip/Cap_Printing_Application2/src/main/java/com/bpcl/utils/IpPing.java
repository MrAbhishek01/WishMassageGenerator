package com.bpcl.utils;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * 
 * @author S.K.R.SUBRAMANYAM REDDY GUIDE BY MR.HIRANAYA SIR
 *
 */
@Service
public class IpPing {

/**
 * 
 * @param ping ipAddrerss
 * @return
 * @throws IOException
 */
	public static boolean ipPing(String ipAddress) {
	    try {
	        Process process = Runtime.getRuntime().exec("ping -c 1 " + ipAddress); // For Linux/macOS
	        // Process process = Runtime.getRuntime().exec("ping -n 1 " + ipAddress); // For Windows
	        int returnVal = process.waitFor();
	        return returnVal == 0;
	    } catch (Exception e) {
	        return false;
	    }
	}

/**
 * ping with ipaddress and port
 * @param address
 * @param port
 * @return
 * @throws IOException
 */
	public static boolean ipPingWithPort(String address, int port) throws IOException {
		Socket crunchifySocket = new Socket();
		try {
			// Connects this socket to the server with a specified timeout value.
			crunchifySocket.connect(new InetSocketAddress(address, port), 10);

			// Return true if connection successful
			return true;
		} catch (IOException exception) {

			// Return false if connection fails
			return false;
		} finally {
			crunchifySocket.close();
		}
	}
/**
 * ping eith url 
 * @param urlString
 * @return
 */
	public static boolean pingWithUrl(String urlString) {		
		try {
			URL url = new URL(urlString);
			URLConnection connection = url.openConnection();

			connection.connect();
			return true;

		} catch (Exception e) {
			return false;
		}

	}

}
