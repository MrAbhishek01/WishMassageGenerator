/*package com.bpcl.utils;


import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bpcl.model.CapQRCode;
import com.bpcl.service.CapQRCodeService;

@Component
public class CapPrinterThread extends Thread {

    @Autowired
    private CapQRCodeService capQRCodeService;

    private static final int PORT = 8081;
    private static final String SERVER_IP = "169.254.156.56";
    private static final int BUFFER_SIZE = 1024;

    @Override
    public void run() {
        startPrintingThread();
    }

    public void startPrintingThread() {
        try (ServerSocket serverSocket = new ServerSocket(PORT, 50, java.net.InetAddress.getByName(SERVER_IP))) {
            System.out.println("Server started, waiting for client connections...");

            try (Socket clientSocket = serverSocket.accept();
                 InputStream input = clientSocket.getInputStream();
                 OutputStream output = clientSocket.getOutputStream()) {

                System.out.println("Client connected from " + clientSocket.getInetAddress());

                List<CapQRCode> capQRCodes = capQRCodeService.getAllCapCodes();
                System.out.println("Fetched QR codes: " + capQRCodes);

                for (CapQRCode capQRCode : capQRCodes) {
                    handleQRCode(capQRCode, input, output);
                }
            }
        } catch (Exception e) {
            System.err.println("Error starting the server: " + e.getMessage());
        }
    }

    private void handleQRCode(CapQRCode capQRCode, InputStream input, OutputStream output) {
        String qrCode = capQRCode.getCapCode();
        try {
            System.out.println("Sending QR code to printer: " + qrCode);
            output.write(qrCode.getBytes());
            output.flush();

            byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead = input.read(buffer);

            if (bytesRead != -1) {
                String clientResponse = new String(buffer, 0, bytesRead);
                System.out.println("Received from client: " + clientResponse);

                if (clientResponse.contains("Printed Successfully")) {
                    System.out.println("QR code printed successfully: " + qrCode);
                    capQRCodeService.updateCapStatus(qrCode, 3); // Update status to 3
                } else {
                    System.err.println("Error printing QR code: " + qrCode);
                }
            } else {
                System.err.println("No response from printer for QR code: " + qrCode);
            }
        } catch (Exception e) {
            System.err.println("Error during communication with client for QR code: " + qrCode + " - " + e.getMessage());
        }
    }
}
*/