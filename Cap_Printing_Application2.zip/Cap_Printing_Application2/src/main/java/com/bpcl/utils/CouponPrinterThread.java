/*package com.bpcl.utils;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bpcl.model.CouponQRCode;
import com.bpcl.service.CouponQRCodeService;

@Component
public class CouponPrinterThread extends Thread {

	@Autowired
	private CouponQRCodeService couponQRCodeService;

	private static final int PORT = 8081;
	private static final String SERVER_IP = "169.254.156.56";
	private static final int BUFFER_SIZE = 1024;

	@Override
	public void run() {
		startingCouponThread();
	}

	public void startingCouponThread() {
		ServerSocket serverSocket = null;
		Socket clientSocket = null;
		InputStream input = null;
		OutputStream output = null;

		try {
			serverSocket = new ServerSocket(PORT, 50, java.net.InetAddress.getByName(SERVER_IP));
			System.out.println("Server started, waiting for client connections...");

			clientSocket = serverSocket.accept();
			System.out.println("Client connected from " + clientSocket.getInetAddress());

			input = clientSocket.getInputStream();
			output = clientSocket.getOutputStream();

			List<CouponQRCode> couponQRCodes = couponQRCodeService.getAllCouponCodes();
			System.out.println("Fetched QR codes: " + couponQRCodes);

			for (CouponQRCode couponQRCode : couponQRCodes) {
				handleQRCode(couponQRCode, input, output);
			}
		} catch (Exception e) {
			System.err.println("Error starting the server: " + e.getMessage());
		} finally {
			closeResources(serverSocket, clientSocket, input, output);
		}
	}

	private void handleQRCode(CouponQRCode couponQRCode, InputStream input, OutputStream output) {
		String qrCode = couponQRCode.getCouponCode();
		try {
			System.out.println("Sending QR code to printer: " + qrCode);
			output.write(qrCode.getBytes());
			output.flush();

			byte[] buffer = new byte[BUFFER_SIZE];
			StringBuilder clientData = new StringBuilder();
			int bytesRead = input.read(buffer);
			if (bytesRead != -1) {
				clientData.append(new String(buffer, 0, bytesRead));
				System.out.println("Received from client: " + clientData);

				if (clientData.toString().contains("Printed Successfully")) {
					System.out.println("QR code printed successfully: " + qrCode);
					couponQRCodeService.updateCouponStatus(qrCode, 3); // Update status to 3
				} else {
					System.err.println("Error printing QR code: " + qrCode);
				}
			} else {
				System.err.println("No response from printer for QR code: " + qrCode);
			}
		} catch (Exception e) {
			System.err
					.println("Error during communication with client for QR code: " + qrCode + " - " + e.getMessage());
		}
	}

	private void closeResources(ServerSocket serverSocket, Socket clientSocket, InputStream input,
			OutputStream output) {
		try {
			if (input != null)
				input.close();
			if (output != null)
				output.close();
			if (clientSocket != null)
				clientSocket.close();
			if (serverSocket != null)
				serverSocket.close();
			System.out.println("Server and client resources have been closed.");
		} catch (Exception e) {
			System.err.println("Error closing resources: " + e.getMessage());
		}
	}
}
*/