package com.bpcl.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bpcl.model.CouponQrCode;

@Repository
public interface CouponQrCodeRepository extends JpaRepository<CouponQrCode, Integer> {

}
