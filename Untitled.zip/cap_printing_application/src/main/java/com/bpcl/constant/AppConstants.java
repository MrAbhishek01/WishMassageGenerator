package com.bpcl.constant;

public class AppConstants {

	public final static Integer ACTIVE_INDENT = 0;

	public final static Integer INACTIVE_INDENT = 3;

	public final static Integer CANCELED_INDENT = 5;
	
	public final static Integer NEW_COUPON_CODE = 0;
	
	public final static Integer NEW_CAP_CODE = 0;

}
