package com.bpcl.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;


@Controller
public class IndentController {
    @GetMapping("/indent")
    public String showIndentPage() {
        return "indent"; // Resolves to /WEB-INF/view/indent.jsp
    
}


	
	
}
