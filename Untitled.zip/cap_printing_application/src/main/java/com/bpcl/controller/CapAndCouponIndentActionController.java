package com.bpcl.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bpcl.model.Indent;
import com.bpcl.service.CapAndCouponQrCodeInsert;

import org.springframework.web.bind.annotation.PostMapping;

@RestController
@RequestMapping("/indentAction")
public class CapAndCouponIndentActionController {
	@Autowired
	private CapAndCouponQrCodeInsert capAndCouponQrCodeInsert;

	@PostMapping("/processIndent")
	public ResponseEntity<String> postMethodName(@RequestBody Indent indent) {
		String indent2 = capAndCouponQrCodeInsert.generateIndent(indent);
		return new ResponseEntity<>(indent2, HttpStatus.OK);
	}

}
