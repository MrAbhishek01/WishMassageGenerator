package com.bpcl.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bpcl.constant.AppConstants;
import com.bpcl.model.CapQrCode;
import com.bpcl.model.CouponQrCode;
import com.bpcl.model.Indent;
import com.bpcl.utils.CapAndCouponQrCodeGenerator;

@Service
public class CapAndCouponQrCodeInsert {
	@Autowired
	private IndentService indentService;
	@Autowired
	private CapAndCouponQrCodeGenerator capAndCouponQrCodeGenerator;

	public String generateIndent(Indent indent) {

		Indent saveIndent = indentService.saveIndent(indent);
		Integer indentID = saveIndent.getId();
		Integer lotQty = saveIndent.getLotQty();

		String batchUuid = UUID.randomUUID().toString();
		Set<String> generatedCodes = new HashSet<>();
		List<CapQrCode> capQRList = new ArrayList<>();
		List<CouponQrCode> couponQRList = new ArrayList<>();

		String indentIdStr = String.valueOf(indentID);
		if (indentIdStr.length() > 8) {
			indentIdStr = indentIdStr.substring(0, 8);
		} else {

			indentIdStr = String.format("%8s", indentIdStr).replace(' ', '0');
		}

		for (int i = 1; i <= lotQty; i++) {
			String seq = String.format("%02d", i);
			String capCode = capAndCouponQrCodeGenerator.generateUniqueAlphanumericCode("CP", indentID, batchUuid, i,
					generatedCodes);
			CapQrCode CapQrCode = new CapQrCode();

			CapQrCode.setCapCode(capCode);
			CapQrCode.setIndentID(indentID);
			CapQrCode.setCreateTime(LocalDateTime.now());
			CapQrCode.setStatus(AppConstants.NEW_CAP_CODE);

			capQRList.add(CapQrCode);

			String couponCode = capAndCouponQrCodeGenerator.generateUniqueAlphanumericCode("CO", indentID, batchUuid, i,
					generatedCodes);

			CouponQrCode CouponQrCode = new CouponQrCode();

			CouponQrCode.setCouponCode(couponCode);
			CouponQrCode.setIndentID(indentID);
			CouponQrCode.setCreateTime(LocalDateTime.now());
			CouponQrCode.setStatus(AppConstants.NEW_COUPON_CODE);

			couponQRList.add(CouponQrCode);
		}

		return "indent submitted successfully";

	}

}
